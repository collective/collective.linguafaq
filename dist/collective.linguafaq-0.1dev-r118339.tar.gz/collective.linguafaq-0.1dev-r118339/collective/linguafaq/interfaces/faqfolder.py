from zope.interface import Interface
# -*- Additional Imports Here -*-


class IFaqFolder(Interface):
    """Description of the Example Type"""

    # -*- schema definition goes here -*-
