from zope.interface import Interface
# -*- Additional Imports Here -*-


class IFaqGroup(Interface):
    """classify faq"""

    # -*- schema definition goes here -*-
