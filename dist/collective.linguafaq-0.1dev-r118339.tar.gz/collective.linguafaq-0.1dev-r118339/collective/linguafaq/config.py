"""Common configuration constants
"""

PROJECTNAME = 'collective.linguafaq'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'FaqGroup': 'collective.linguafaq: Add FaqGroup',
    'FaqItem': 'collective.linguafaq: Add FaqItem',
    'FaqFolder': 'collective.linguafaq: Add FaqFolder',
}
