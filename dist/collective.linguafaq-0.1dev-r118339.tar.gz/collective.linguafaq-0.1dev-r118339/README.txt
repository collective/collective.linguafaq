.. contents::

.. Note!
   -----
   Update the following URLs to point to your:

   - code repository
   - bug tracker
   - questions/comments feedback mail
   (do not set a real mail, to avoid spams)

   Or remove it if not used.

- Code repository: http://svn.somewhere.com/...
- Questions and comments to somemailing_list
- Report bugs at http://bug.somewhere.com/..

